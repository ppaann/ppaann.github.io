/**
 * @ngdoc module
 * @name layouts
 * @module layouts
 *
 * @description
 * Page layout handling system.
 */
(function(angular) {

angular.module('modules.core.layout', ['modules.core.neo', 'modules.core.messaging']);

/**
 * @ngdoc directive
 * @name neoLayout
 * @module modules.core.layout
 *
 * @description
 * Whole page container that tunes page layout defined currently in the setup.
 *
 * Scope:
 *
 *   * `layout` - Name of the currently selected layout.
 *
 * @example
 * ```html
 * <neo-layout></neo-layout>
 * ```
 */
function LayoutController($scope, setup) {
    $scope.layout = setup.layout;
    $scope.$on('refresh', function(){$scope.layout= setup.layout;} );
}

function neoLayout() {

    return {
        restrict: 'E',
        templateUrl: 'www/ui/modules/core/layout.html',
        controller: ['$scope', 'setup', LayoutController]
    };
}
angular.module('modules.core.layout').directive('neoLayout', [neoLayout]);

})(angular);
