(function(angular) {

angular.module('modules.core.messaging', ['modules.core.neo']);

// Handle for global messages of setup.
var messages;

angular.module('modules.core.messaging').run(['setup', function(setup){messages = setup.messages;}]);

angular.module('modules.core.messaging').service('neoMessageService',
    function () {
      return {
          add: function (type, title, message, permanent, icon) {

              messages.items.push(new Message({
                  type: type,
                  title: title,
                  message: message,
                  permanent: permanent,
                  icon: icon
              }));
          },

          remove: function (message) {
              var index = messages.items.indexOf(message);
              messages.items.splice(index, 1);
          },
    };
  }
);

angular.module('modules.core.messaging').service('danger', ['neoMessageService', function(neoMessageService) {
    return function(title, msg) {neoMessageService.add('danger', msg ? title : '', msg ? msg : title, false, '');};
}]);

angular.module('modules.core.messaging').service('warning', ['neoMessageService', function(neoMessageService) {
    return function(title, msg) {neoMessageService.add('warning', msg ? title : '', msg ? msg : title, false, '');};
}]);

angular.module('modules.core.messaging').service('success', ['neoMessageService', function(neoMessageService) {
    return function(title, msg) {neoMessageService.add('success', msg ? title : '', msg ? msg : title, false, '');};
}]);

angular.module('modules.core.messaging').service('info', ['neoMessageService', function(neoMessageService) {
    return function(title, msg) {neoMessageService.add('info', msg ? title : '', msg ? msg : title, false, '');};
}]);

angular.module('modules.core.messaging').directive('neoMessages',['neoMessageService', function(neoMessageService){

    return {
        restrict: 'EA',
        templateUrl: 'www/ui/modules/core/messaging.html',
        link: function(scope) {
            scope.messages = messages.items;

            scope.remove = function(message){
                neoMessageService.remove(message);
            }
        },
    };
  }]);

})(angular);
