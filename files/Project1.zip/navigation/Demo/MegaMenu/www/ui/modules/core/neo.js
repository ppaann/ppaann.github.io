/**
 * @ngdoc module
 * @name modules.core.neo
 * @module modules.core.neo
 *
 * @description
 * This is the bootstrap module for Neo-application, which takes care of loading essential
 * components for running the application.
 *
 * Signals:
 *
 *   * `refresh` - A full screen redraw request emitted on call to `refresh()` function of this module.
 */
(function(angular) {

angular.module('modules.core.neo', ['modules.core.layout', 'widgets', 'pages', 'ui.router', 'ui.router.state', 'ui.bootstrap']);

// System setup.
angular.module('modules.core.neo').value('setup', new Setup());
// Page map.
angular.module('modules.core.neo').value('pages', new Pages());


// Handle of the $stateProvider.
var stateProvider;
// Handle of the $urlRouterProvider.
var urlRouterProvider;
// Handle of the $httpProvider.
var httpProvider;
// Handle of the $rootScope;
var rootScope;
// Handle of the $location;
var location;

/**
 * Configure the module.
 *
 * Set up handles here that cannot be accessed directly from this module.
 */
function config($stateProvider, $urlRouterProvider, $httpProvider) {
    // Clone some handles.
    stateProvider = $stateProvider;
    urlRouterProvider = $urlRouterProvider;
    httpProvider = $httpProvider;
}
angular.module('modules.core.neo').config(['$stateProvider', '$urlRouterProvider', '$httpProvider', config]);

/**
 * Set up states based on the page map.
 */
function run($state, $location, $rootScope, pages, setup) {

    // Generic handler for pages.
    function page_controller($scope, $stateParams) {
        angular.extend($scope, $stateParams);
    }

    // Check the roles before allowing to enter to the particular page.
    function state_police(event, toState, toParams, fromState, fromParams) {
        var page = pages.find(toState.name);
        // TODO: Here we can record the URL attempted and go to the login if no user.
        if(!setup.user.hasRole(page.roles)) {
            // Handle server problem, where user has no roles.
            if(setup.user.roles.length == 0) {
                setup.logout();
                d("User has no roles.");
            }
            event.preventDefault();
            $state.go(pages.defaultPage(setup));
        }
    }
    $rootScope.$on('$stateChangeStart', state_police);

    // Clone even more handles.
    rootScope = $rootScope;
    location = $location;

    // Set up the state engine.
    urlRouterProvider.otherwise("/");
    for(var m in pages.items) {
        var name = pages.items[m].name;
        if(!$state.get(name) && pages.items[m].url) {
            var state = {
                    url: pages.items[m].url,
                    templateUrl: pages.items[m].templateUrl,
                    controller: ['$scope', '$stateParams', page_controller]
                };
            stateProvider.state(name, state);
        }
    }

    // Match Django CSRF implementation
    httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
    httpProvider.defaults.xsrfCookieName = 'csrftoken';

    // Signal to force redraw of the page template is needed here.
    refresh();
}
angular.module('modules.core.neo').run(['$state', '$location', '$rootScope', 'pages', 'setup', run]);


/**
 * @ngdoc function
 * @name refresh
 * @module modules.core.neo
 *
 * Refresh the whole screen.
 */
function refresh() {
    return function() {
        var path=location.path();
        rootScope.$broadcast('$locationChangeSuccess', path, path);
        rootScope.$broadcast('refresh');
    };
}
angular.module('modules.core.neo').factory('refresh', refresh);

/**
 * @ngdoc directive
 * @name neoSetup
 * @module modules.core.neo
 *
 * @description
 * Brings the system setup into the current scope.
 *
 * Scope:
 *
 *   * `setup` - The currently effective `Setup` object.
 *
 * @example
 * ```html
 * <neo-setup>
 *   Welcome <i>{{setup.user.name()}}</i>!
 * </neo-setup>
 * ```
 */
function setupController($scope, setup) {
    $scope.setup=setup;
    $scope.$on('refresh', function(){$scope.setup=setup;});
}
function neoSetup() {
    return {
        controller: ['$scope', 'setup', setupController]
    };
}
angular.module('modules.core.neo').directive('neoSetup', neoSetup);

})(angular);
