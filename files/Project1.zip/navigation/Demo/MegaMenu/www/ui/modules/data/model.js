/**
 * @ngdoc module
 * @name modules.data.models
 * @module modules.data.models
 *
 * @description
 * Interface to handling data models.
 */
(function(angular) {

    var moduleName = 'modules.data.model';

    angular.module(moduleName, ['modules.core.network']);

    // Handle for storage.
    var storage;

    /**
     * Resolve constructor of a model by its name.
     *
     * @param {string} str: Name of the model.
     * @return {function|undefined} A constructor if model valid.
     */
    function model_of(str) {
        /* jshint -W061 */
        // Make eval() safe here.
        if(str.match(/^[A-Za-z0-9]+$/))
            return eval(str);
        /* jshint +W061 */
    }

    /**
     * Fetch a copy of an object from the remote API.
     *
     * @param {string} model_name Name of the class.
     * @param {string} url API call to fetch data,
     * @param {Function} success Success call-back function.
     * @param {Function} fail Error call-back function.
     */
    function model_read(model_name, url, success, fail) {
        storage.get(url, model_of(model_name), success, fail);
    }

    /**
     * @ngdoc factory
     * @name models
     * @module modules.data.models
     *
     * @description
     * Provide functions for accessing data model services.
     */
    angular.module(moduleName).factory('models',

            ['storage', function model(_storage) {

                storage = _storage;

                return {
                    class_of: model_of,
                    read: model_read
                };
            }]);

})(angular);
