/**
 * @ngdoc module
 * @name modules.user.login
 * @module modules.user.login
 *
 * @description
 * Handler for user authentication.
 */
(function(angular) {

angular.module('modules.user.login', ['modules.core.neo', 'modules.core.network', 'ui.router.state']);

/**
 * @ngdoc controller
 * @name LoginController
 * @module modules.user.login
 *
 * @description
 * Provide controls and authentication state in order to handle logging in and out.
 *
 * Scope:
 *
 *   * `is_logged_in` - Set true if there is authenticated user.
 *   * `model` - Custom model for filling in user name and password.
 *   * `logout()` - Perform logging user out.
 *   * `submit(model)` - Perform logging user in with the given model containing `username` and `password`.
 */
function LoginController($scope, setup, $state, refresh, storage) {

    $scope.model = new Values({name: 'Login', values: [{ref: 'username', type: 'string', options: {required: true}},
                                                       {ref: 'password', type: 'string', options: {required: true, password: true}},
                                                       ]});

    $scope.is_logged_in = setup.hasUser();

    $scope.logout = function() {
        storage.post('api/user/logout', {}, null, function() {
            setup.logout();
            $state.go('Login');
            refresh();
        });
    };

    $scope.submit = function(model) {
        storage.post('api/user/login', model, User, function(user) {
            setup.login(user);
            refresh();
            $state.go('Home');
        }, function(error) {
            // TODO: Remove and replace with proper implementation once
            // messaging module is ready
            alert("Login failed.");
        });
    };

    $scope.$on('refresh', function(){$scope.is_logged_in = setup.hasUser();});
}
angular.module('modules.user.login').controller('LoginController', ['$scope', 'setup', '$state', 'refresh', 'storage', LoginController]);

/**
 * @ngdoc directive
 * @name neoLoginLogout
 * @module modules.user.login
 *
 * @description
 * Provide a control for user to log out or in depending on the current state.
 *
 * Scope:
 * @see LoginController
 *
 * @example
 * ```html
 * <neo-login-logout></neo-login-logout>
 * ```
 */
function neoLoginLogout() {
    return {
        template: '<a ng-show="is_logged_in" ng-click="logout()">Logout</a><a ng-show="!is_logged_in" ui-sref="Login">Login</a>',
        controller: ['$scope', 'setup', '$state', 'refresh', 'storage', LoginController]
        };
}
angular.module('modules.user.login').directive('neoLoginLogout', neoLoginLogout);

})(angular);
