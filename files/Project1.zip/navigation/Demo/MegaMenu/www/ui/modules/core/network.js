/**
 * @ngdoc module
 * @name modules.core.network
 * @module modules.core.network
 *
 * @description
 *
 * Provides the communication services for the application. In addition to fetching and caching files
 * it handles REST-API calls. It determines the operating `mode` from the system setup and decides if
 * data is fetched over API or directly form the fixtures. If we are not running normal server-based
 * setup, then we are simulating API calls by loading files. For example, API call to 'data/customer'
 * will check the file 'devsite/fixtures/api/data/customer.js' and if found it is loaded. It can be
 * either pure JSON-data which is returned as a response. Or, it can contain functions like GET or POST
 * that takes a request JSON as an argument and should return response as JSON. In the case of error
 * an exception should be thrown.
 */
(function(angular) {

angular.module('modules.core.network', ['modules.core.neo']);

// Cached resource files and functions. Keys are file paths followed by optional colon and function name.
var cache;

function config($cacheFactory) {
    cache = $cacheFactory('neo-cache');
}
angular.module('modules.core.network').run(['$cacheFactory', config]);

/**
 * @ngdoc service
 * @name storage
 * @module modules.core.network
 *
 * @description
 * Handle retrieving and storing data.
 *
 * @example
 * To fetch and cache a data file, storage is used simply as
 * ```js
 *    storage.file('www/data/path/example_file.csv');
 * ```
 *
 * @example
 * Getting data over API and automatically mapping it to model called `Example`, can be done as
 * ```js
        get: function(url, model, success) {
 *    storage.file('api/data/example', Example, function(example) {...});
 * ```
 * Here the success-function is called with the instantiated `Example` object. If class is left as null
 * instead of Example, then raw data is passed instead.
 */
function storage($http, setup) {

    /**
     * Figure out what kind of call we are handling.
     *
     * @param {string} url Local part of the URL to fetch.
     * @return Either 'resource' or 'api' or null if not known.
     */
    function call_type(url) {
        if(url.substr(0,4) == 'www/')
            return 'resource';
        if(url.substr(0,4) == 'api/')
            return 'api';
        return null;
    }

    /**
     * Handler for actual storage interaction.
     *
     * @param {string} method A method of call e.g. GET or POST etc.
     * @param {string} url Local part of the URL to fetch.
     * @param {object} data Data to send if any (for `NeoModel` objects `forPOST()` is called to construct data).
     * @param {NeoModel} model A model handling the expected response data (use null for raw).
     * @param {function(NeoModel)} success Function to execute after successful loading.
     * @param {function(string)} fail Function to execute after failure with error message as an argument (optional).
     */
    function execute(method, url, data, model, success, fail) {

        // Pre-process data if it is our own model type.
        if(data) {
            if('forPOST' in data)
                data = data.forPOST();
        }

        // Function for handling successful response.
        function success_handler(data, status, headers, config) {

            if(model) {
                if(angular.isArray(data)) {
                    for(var i in data)
                        data[i] = new model(data[i]);
                }
                else
                    data = new model(data);
            }
            if(success)
                success(data);
            else
                d("No handler for data received from '" + url + "': ", data);
        }

        // Function for handling error response.
        function error_handler(data, status, headers, config) {
            var msg = data.details;
            if(!msg) {
                if(data !== '')
                    msg = "Internal error: " + angular.toJson(data);
                else
                    msg = "Unknown error.";
            }
            d("Call to '" + url + "' failed (" + status + "): " + msg);
            if(fail)
                fail(msg);
            else
                ;
                // TODO: By default call the messaging system module here with error message.
        }

        var type = call_type(url);

        // Special handling for local development.
        if(type == 'api') {
            if(setup.mode == 'local-file')
                return execute_local(method, url, data, model, success_handler, error_handler);
        } else if(type != 'resource')
            // Ignore unknown URL.
            return d("Unsupported resource URL: " + url);

        // Construct real API call and execute it.
        var config = {method: method, url: url, data: data};

        $http(config).success(success_handler).error(error_handler);
    }

    /**
     * Execute a function in local API simulation.
     *
     * API calls are simulated with files written either as Javascript code or as JSON data.
     * For example a GET-call to 'api/foo/bar' is performed as follows:
     *
     * 1. A file api/foo/bar.js is loaded.
     * 2. If file has GET-function, it is called with request data as an argument and return
     *    value is assumed as JSON response.
     * 3. If file does not have GET or any other method function (POST, PUT, DELETE) it is
     *    assumed as JSON-data and returned directly. This applies no matter what method we
     *    use in API-call.
     *
     * Note: this function pollutes global name space in order to smuggle functions
     * out of API files.
     */
    function run_local(file, method, fn) {

        // Use old if already loaded.
        var stored = cache.get(file + ':' + method);
        if(stored)
            return fn(stored);

        // Clean up old.
        /* jshint -W051 */
        try {delete GET;} catch(err) {}
        try {delete POST;} catch(err) {}
        try {delete PUT;} catch(err) {}
        try {delete DELETE;} catch(err) {}
        /* jshint +W051 */

        // Load all methods you can find and ignore errors.
        d("Loading " + file);
        $script(file, function(data) {

            var found;

            try {
                cache.put(file + ':GET', GET);
                found = true;
            } catch(err) {}

            try {
                cache.put(file + ':POST', POST);
                found = true;
            } catch(err) {}

            try {
                cache.put(file + ':PUT', PUT);
                found = true;
            } catch(err) {}

            try {
                cache.put(file + ':DELETE', DELETE);
                found = true;
            } catch(err) {}

            // If we found a function based implementation, let us use it.
            if(found)
                return fn(cache.get(file + ':' + method));

            // Ah, it is pure JSON data, so create function for it then.
            $http.get(file).success(function(json) {
                cache.put(file + ':' + method, function() {return json;});
                fn(cache.get(file + ':' + method));
            });
        });
    }

    /**
     * Helper to handle stand-alone local development API simulation.
     *
     * If URL ends with a number, then we assume that the URL without the number gives
     * full list of objects. We load those and then look up for an object having an ID
     * matching the number and return that. Otherwise we will raise an error.
     */
    function execute_local(method, url, data, model, success, fail) {

        // Strip off the ID element.
        var has_id = url.match(/(\/([0-9]+))$/);
        var id = null;
        if(has_id) {
            url = url.substr(0, url.length - has_id[1].length)
            id = has_id[2];
        }

        // Execute the file content.
        var file = '../../devsite/fixtures/' + url + '.js';

        run_local(file, method, function(fn) {
            var ret;

            try {
                ret = fn(data);
                // Apply the ID argument here if given.
                if(id) {
                    var found = false;
                    for(var i in ret) {
                        if(ret[i].id == id) {
                            ret = ret[i];
                            found = true;
                            break;
                        }
                    }
                    // Not found.
                    if(!found)
                        throw new Error("Cannot find an object with ID '" + id + "' from API file '" + file + "'.");
                }
                // All good for calling the success function.
                success(ret);
            } catch(err) {
                fail({details: err}, 400, function(){}, {});
            }
        });
    }

    return {
        /**
         * Retrieve data from the storage over API.
         *
         * @param {string} url Local part of the URL to fetch.
         * @param {NeoModel} model A model handling the data received.
         * @param {function(NeoModel)} success  Function to execute after successful loading.
         * @param {function(string)} fail Function to execute in the case of failure (optional).
         */
        get: function(url, model, success, fail) {
            execute('GET', url, null, model, success, fail);
        },

        /**
         * Delete a resource from the storage over API.
         *
         * @param {string} url Local part of the URL to delete.
         * @param {NeoModel} model A model handling the data received if any.
         * @param {function(NeoModel)} success  Function to execute after successful deleting.
         * @param {function(string)} fail Function to execute in the case of failure (optional).
         */
        delete: function(url, model, success, fail) {
            execute('DELETE', url, null, model, success, fail);
        },

        /**
         * Send data to the storage over API.
         *
         * @param {string} url Local part of the URL to post to.
         * @param {NeoModel} post A model of the post data.
         * @param {NeoModel} model A model of the received data.
         * @param {function(NeoModel)} success Function to execute after successful loading.
         * @param {function(string)} fail Function to execute in the case of failure (optional).
         */
        post: function(url, post, model, success, fail) {
            execute('POST', url, post, model, success, fail);
        },

        put: function(url, post, model, success, fail) {
            execute('PUT', url, post, model, success, fail);
        },

        /**
         * Fetch a possible cached resource file content.
         *
         * @param {string} url Local part of the URL to file.
         * @param {function(string)} success Function which is called after loading the content with it as a parameter.
         */
        file: function(url, success) {
            var cached = cache.get(url);
            if(cached)
                return success(cached);

            d("Loading " + url);

            $http({method: 'GET', url: url}).success(function(data) {
                cache.put(url, data);
                success(data);
            });
        }
    };
}
angular.module('modules.core.network').factory('storage', ['$http', 'setup', storage]);

})(angular);
