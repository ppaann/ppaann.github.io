/**
 * @ngdoc module
 * @name pages.system_admin
 * @module pages.system_admin
 *
 * @description
 *
 */
(function(angular) {

    // Scope of currently displayed menus.
    var menu_scope;

    angular.module('pages.system_admin', ['modules.core.neo']);

    /**
     * @ngdoc controller
     * @name SystemAdminController
     * @module pages.system_admin
     *
     * @description
     *
     * Scope:
     *
     *
     */
    function SystemAdminController($scope, storage) {
    }
    angular.module('pages.system_admin').controller('SystemAdminController', ['$scope', 'storage', SystemAdminController]);

})(angular);
