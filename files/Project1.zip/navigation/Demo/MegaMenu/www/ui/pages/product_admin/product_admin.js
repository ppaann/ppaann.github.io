/**
 * @ngdoc module
 * @name pages.product_admin
 * @module pages.product_admin
 *
 * @description
 *
 */
(function(angular) {

    // Scope of currently displayed menus.
    var menu_scope;

    angular.module('pages.product_admin', ['modules.core.neo']);

    /**
     * @ngdoc controller
     * @name ProductAdminController
     * @module pages.product_admin
     *
     * @description
     *
     * Scope:
     *
     *
     */
    function ProductAdminController($scope, storage) {
    }
    angular.module('pages.product_admin').controller('ProductAdminController', ['$scope', 'storage', ProductAdminController]);

})(angular);
