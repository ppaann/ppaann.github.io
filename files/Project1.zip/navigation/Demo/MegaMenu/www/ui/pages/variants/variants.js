/**
 * @ngdoc module
 * @name pages.variants
 * @module pages.variants
 *
 * @description
 *
 */
(function(angular) {

    angular.module('pages.variants', []);

})(angular);
