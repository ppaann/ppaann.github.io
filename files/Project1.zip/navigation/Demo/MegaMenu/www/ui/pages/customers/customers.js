/**
 * @ngdoc module
 * @name pages.customers
 * @module pages.customers
 *
 * @description
 *
 */
(function(angular) {

    var config = {
        'baseUrl': 'api/customers/model-resolver?model=',
        'buttonLabels': {
            'create': 'Create new',
            'hide': 'Hide form'
        }
    };

    var adminModels = [
        {
            id: 'region',
            description: "Region",
            modelClass: Region,
            createValues: {name: 'Region', values: [{ref: 'name', type: 'string', options: {required: true}}]}
        },
        {
            id: 'country',
            description: "Country",
            modelClass: Country,
            createValues: {name: 'Country', values: [
                {ref: 'name', type: 'string', options: {required: true}},
                {ref: 'alpha2', type: 'string', options: {required: true}},
                {ref: 'group', type: 'string', options: {required: false}}
            ]}
        },
        {
            id: 'corporate',
            description: "Global corporations",
            modelClass: Corporation,
            createValues: {name: 'Corporation', values: [
                {ref: 'name', type: 'string', options: {required: true}}
            ]}
        },
        {
            id: 'moid',
            description: "Mobile Operator ID",
            modelClass: MOID,
            createValues: {name: 'MOID', values: [
                {ref: 'moid', type: 'string', options: {required: true}}
            ]}
        },
        {
            id: 'mcc',
            description: "Mobile Country Code",
            modelClass: MCC,
            createValues: {name: 'MCC', values: [
                {ref: 'mcc', type: 'string', options: {required: true}},
                {ref: 'country', type: 'string', options: {required: true}}
            ]}
        },
        {
            id: 'mnc',
            description: "Mobile Network Code",
            modelClass: MNC,
            createValues: {name: 'MNC', values: [
                {ref: 'mcc', type: 'string', options: {required: true}},
                {ref: 'mnc', type: 'string', options: {required: true}},
                {ref: 'network', type: 'string', options: {required: true}}
            ]}
        },
        {
            id: 'countrygroup',
            description: "Country group",
            modelClass: CountryGroup,
            createValues: {name: 'Country group', values: [
                {ref: 'name', type: 'string', options: {required: true}},
                {ref: 'groupcountries', type: 'string', options: {required: false}}
            ]}
        },
        {
            id: 'simlock',
            description: "SIM Lock",
            modelClass: SIMLock,
            createValues: {name: 'SIM lock', values: [
                {ref: 'name', type: 'string', options: {required: true}},
                {ref: 'configkey', type: 'string', options: {required: true}}
            ]}
        },
        {
            id: 'operator',
            description: "Operator",
            modelClass: Operator,
            createValues: {name: 'Operator', values: [
                {ref: 'name', type: 'string', options: {required: true}},
                {ref: 'spn', type: 'string', options: {required: true}},
                {ref: 'gid1', type: 'string', options: {required: true}},
                {ref: 'gid2', type: 'string', options: {required: true}},
                {ref: 'imsi_start', type: 'string', options: {required: true}},
                {ref: 'imst_end', type: 'string', options: {required: true}},
                {ref: 'pnn', type: 'string', options: {required: true}},
                {ref: 'carrier_id', type: 'string', options: {required: true}},
                {ref: 'simlock', type: 'string', options: {required: true}},
                {ref: 'mnvo', type: 'string', options: {required: true}},
                {ref: 'operatornetworks', type: 'string', options: {required: true}}
            ]}
        },
        {
            id: 'tradecustomer',
            description: "Trade customer",
            modelClass: TradeCustomer,
            createValues: {name: 'Trade customer', values: [
                {ref: 'name', type: 'string', options: {required: true}},
                {ref: 'group', type: 'string', options: {required: false}}
            ]}
        },
        {
            id: 'customer',
            description: "Customer",
            modelClass: Customer,
            createValues: {name: 'Customer', values: [
                {ref: 'customer', type: 'string', options: {required: true}},
                {ref: 'country', type: 'string', options: {required: true}},
                {ref: 'region', type: 'string', options: {required: true}},
                {ref: 'moid', type: 'string', options: {required: true}},
                {ref: 'operator', type: 'string', options: {required: true}},
                {ref: 'mcc', type: 'string', options: {required: true}}
            ]}
        },
    ];

    function CustomersAdminCtrl($rootScope, $scope, storage) {

        $scope.baseUrl = null;
        $scope.selected = null;
        $scope.selectList = adminModels;

        // Admin data selection changed -> change UI layout accordingly
        $scope.$on('admin-selection', function(event, selection){
            if (selection) {
                var cls = selection.modelClass;
                $scope.selected = selection.id;
                $scope.baseUrl = config.baseUrl + $scope.selected;
                $scope.model = new cls(selection.createValues);
            }
        });

        // Toggle admin form visibility
        $scope.showForm = true;
        $scope.formStatus = function() {
            $scope.buttonLabel = ($scope.showForm === true) ? config.buttonLabels.create : config.buttonLabels.hide;
            $scope.showForm = !$scope.showForm;
        };

        // Submit new admin data to server
        $scope.submit = function(model) {
            var url = $scope.baseUrl + '&action=add';
            storage.post(url, model, null, function(data) {

                // Everything OK, hide the form and reload table
                $scope.formStatus();
                $rootScope.$broadcast("table-reload");
            });
        };

        $scope.formStatus();
    };

    var moduleName = 'pages.customers';
    var module = angular.module(moduleName, ['ngSanitize', 'ui.select']);
    module.controller('CustomersAdminController', ['$rootScope', '$scope', 'storage', CustomersAdminCtrl]);

})(angular);
