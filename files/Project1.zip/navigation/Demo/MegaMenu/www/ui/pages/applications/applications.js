/**
 * @ngdoc module
 * @name pages.applications
 * @module pages.applications
 *
 * @description
 *
 */
(function(angular) {
  angular.module('pages.applications', ['modules.core.neo']);

  /**
   * @ngdoc controller
   * @name ApplicationsController
   * @module pages.applications
   *
   * @description
   *   Common controller for Applications view.
   */
  function ApplicationsController($scope, storage) {
  }

  angular.module('pages.applications')
    .controller('ApplicationsController', ['$scope',
                                           'storage', ApplicationsController]);
})(angular);
