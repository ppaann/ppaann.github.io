/**
 * @ngdoc module
 * @name pages
 * @module pages
 *
 * @description
 * Top level module containing all page controllers.
 */
(function(angular) {

angular.module('pages', ['pages.developer_tools',
                         'pages.user',
                         'pages.my_page',
                         'pages.variants',
                         'pages.applications',
                         'pages.customers',
                         'pages.product_admin',
                         'pages.rest_api',
                         'pages.sw_delivery',
                         'pages.system_admin'
                         ]);

})(angular);
