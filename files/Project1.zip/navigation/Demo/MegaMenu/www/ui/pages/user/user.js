/**
 * @ngdoc module
 * @name pages.user.login
 * @module pages.user.login
 *
 * @description
 * Page for entering login details.
 */
(function(angular) {

angular.module('pages.user', ['modules.user.login']);

})(angular);
