/**
 * @ngdoc module
 * @name pages.sw_delivery
 * @module pages.sw_delivery
 *
 * @description
 *
 */
(function(angular) {

    // Scope of currently displayed menus.
    var menu_scope;

    angular.module('pages.sw_delivery', ['modules.core.neo']);

    /**
     * @ngdoc controller
     * @name SwDeliveryController
     * @module pages.sw_delivery
     *
     * @description
     *
     * Scope:
     *
     *
     */
    function SwDeliveryController($scope, storage) {
    }
    angular.module('pages.sw_delivery').controller('SwDeliveryController', ['$scope', 'storage', SwDeliveryController]);

})(angular);
