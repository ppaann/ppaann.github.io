/**
 * @ngdoc module
 * @name pages.my_page
 * @module pages.my_page
 *
 * @description
 *
 */
(function(angular) {

    angular.module('pages.my_page', ['modules.core.neo']);

    function MyPageController($scope, setup, pages) {
        var menu = pages.userPages(setup.user.roles);
        $scope.menu = menu.items;
        // TODO: Favourites implementation using user profile and click counting.
    }

    angular.module('pages.my_page').controller('MyPageController', ['$scope', 'setup', 'pages', MyPageController]);

})(angular);
