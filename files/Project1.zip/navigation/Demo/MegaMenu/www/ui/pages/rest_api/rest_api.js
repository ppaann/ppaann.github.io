/**
 * @ngdoc module
 * @name pages.rest_api
 * @module pages.rest_api
 */
(function(angular) {

angular.module('pages.rest_api', ['modules.core.neo', 'modules.data.model']);

/**
 * @ngdoc controller
 * @name RestApiController
 * @module pages.rest_api
 */
function RestApiController($scope, storage, models, info) {

    $scope.model = "Configuration";
    $scope.url = "api/configurations/1";
    $scope.submit = function() {
        storage.get($scope.url, models.class_of($scope.model), function(data){
            d(data);
            info("Read the console log for response!");
        })
    }
}
angular.module('pages.rest_api').controller('RestApiController', ['$scope', 'storage', 'models', 'info', RestApiController]);

})(angular);
