// TODO: Docs

(function(angular) {

angular.module('pages.developer_tools', ['modules.core.network', 'modules.core.messaging']);

function DeveloperController($scope, storage, info) {

    $scope.info = function(title, msg) {
        info(title, msg);
    }
}

angular.module('pages.developer_tools').controller('DeveloperController', ['$scope', 'storage', 'info', DeveloperController]);

})(angular);
