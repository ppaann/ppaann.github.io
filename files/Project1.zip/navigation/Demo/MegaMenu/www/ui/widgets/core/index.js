/**
 * @ngdoc module
 * @name widgets.core
 * @module widgets.core
 *
 * @description
 * The collection of the general purpose widgets.
 */
(function(angular) {

angular.module('widgets.core', ['widgets.core.menu']);

})(angular);
