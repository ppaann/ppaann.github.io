/**
 * @ngdoc module
 * @name widgets.data.select
 * @module widgets.data.select
 *
 * @description
 * Selection list implementation using AngularJS ui-select module.
 */
(function(angular) {

    /**
     * @ngdoc directive
     * @name neoSelect
     * @module widgets.data.select
     *
     * @description
     * Selection list wrapper for Neo code. Event ('selection-changed' by default) will be sent every
     * time new item has been selected.
     *
     * Attributes:
     *
     *   * 'selectTitle' - Text to show when nothing has been selected
     *   * 'selectKey' - Attribute value to show from selection item
     *   * 'selectList' - Selection list; may contain reference to parent scope attribute
     *   * 'selectedId' - Default selected item ID
     *   * 'selectEvent' - Name of event to be sent for selection changes
     *
     * @example
     * Basic dropdown list:
     * ```html
     * <neo-select select-title="Select Neo data..." select-list="selectList" select-key="description"></neo-select>
     * ```
     * where the selection data is defined in controller:
     *   @scope.selectList = [{id: 'one', description: '1st item'}, {id: 'two', description: '2nd item'}];
     */
    function NeoSelect() {

        var controller = function($scope, $element, $attrs) {
            var selectEventName = $attrs.selectEvent || 'selection-changed';

            $scope.selectionObject = {};
            $scope.selectionObject.selection = null;

            $scope.selectKey = $attrs.selectKey || 'description';
            $scope.selectTitle = $attrs.selectTitle || 'Select data...';

            // Is selection list available in parent scope?
            $scope.selectList = ($attrs.selectList) ? $scope.$parent[$attrs.selectList] || [] : [];

            // Is selection list then available as HTML attribute value?
            if ($scope.selectList.length === 0) {
                var selectList = $scope.$eval($attrs.selectList);
                if (angular.isArray(selectList))
                    $scope.selectList = selectList;
            }

            // Select default, if valid and present
            var selectedId = $attrs.selectedId;
            if (selectedId) {
                for (var i = 0; i < $scope.selectList.length; i++) {
                    var intValue = parseInt(selectedId);
                    if ($scope.selectList[i].id === selectedId || $scope.selectList[i].id === intValue) {
                        $scope.selectionObject.selection = $scope.selectList[i];
                        break;
                    }
                }
            }

            // Emit selection changed message upwards through the scope hierarchy.
            $scope.$watch('selectionObject.selection', function () {
                $scope.$emit(selectEventName, $scope.selectionObject.selection);
            });
        };

        return {
            restrict: 'E',
            controller: ['$scope', '$element', '$attrs', controller],
            templateUrl: 'www/ui/widgets/data/select.html',
            scope: {},
        };
    };

    var moduleName = 'widgets.data.select';
    var module = angular.module(moduleName, ['ngSanitize', 'ui.select']);
    module.directive('neoSelect', NeoSelect);

})(angular);
