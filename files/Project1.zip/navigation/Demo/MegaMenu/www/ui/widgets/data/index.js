/**
 * @ngdoc module
 * @name widgets.data
 * @module widgets.data
 *
 * @description
 * Widgets for data handling.
 */
(function(angular) {

angular.module('widgets.data', ['widgets.data.forms',
                                'widgets.data.table',
                                'widgets.data.select']);

})(angular);
