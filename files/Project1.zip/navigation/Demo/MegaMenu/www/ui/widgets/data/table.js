/**
 * @ngdoc module
 * @name widgets.data.table
 * @module widgets.data.table
 *
 * @description
 * Simpler interface to Angular DataTables.
 */
(function(angular) {

angular.module('widgets.data.table', ['datatables', 'modules.core.neo']);

// Default classes to use if none given to the neoTable.
var default_classes = "table table-bordered table-striped hover";

// Number of data tables in use.
var tables_in_use = 0;
//Handle for storage access.
var storage;
//Handle for setup.
var setup;
// Handle for interpolate service.
var interpolate;
// Handles for DataTables API:
var DTOptionsBuilder;
var DTColumnBuilder;
var DTDefaultOptions;

/**
 * Collect handles for further use.
 */
function run(_storage, _DTOptionsBuilder, _DTColumnBuilder, _DTDefaultOptions, $interpolate, _setup) {
    storage = _storage;
    setup = _setup;
    DTOptionsBuilder = _DTOptionsBuilder;
    DTColumnBuilder = _DTColumnBuilder;
    DTDefaultOptions = _DTDefaultOptions;
    interpolate = $interpolate;
}
angular.module('widgets.data.table').run(['storage', 'DTOptionsBuilder', 'DTColumnBuilder', 'DTDefaultOptions', '$interpolate', 'setup', run]);

/**
 * Constructs a DataTables rendering function to link columns in the table.
 *
 * Each {id} or any other field name in single braces is converted to the actual value in the URL.
 */
function linkRenderer(url) {

    return function(data, type, full, meta) {

        // This is only used for display.
        if(type != 'display')
            return data;

        // Create a link by doubling braces and embedding values using $interpolate service.
        var link  = interpolate(url.replace(/{/g, '{{').replace(/}/g, '}}'))(full);

        // Wrap the content inside A-tag.
        return '<a href="#' + link + '">' + data + '</a>';
    };
}

/**
 * @ngdoc directive
 * @name neoTable
 * @module widgets.data.table
 *
 * @description
 * A wrapper to make usage of DataTables easier to integrate into Neo code. You can set up simple tables just by using
 * directives. Additional tuning can be done by providing normal 'dtOptions' and/or 'dtColumns' variables in the
 * parent controller. Those are used as default. Then automatically parsed options from directives overrides those.
 *
 * Scope:
 *
 *   * `table_id` - An ID of the HTML element containing the dataTable.
 *   * `dtOptions` - Options for Angular DataTables as constructed by DTOptionsBuilder.
 *   * `dtColumns` - Column definitions for Angular DataTables as constructed by DTColumnBuilder.
 *   * `classes` - CSS classes for the table.
 *   * `can_open_rows` - If set, we have rows that can contain additional data.
 *
 * Attributes:
 *
 *   * `src` - An URL for API call to fetch data.
 *
 * Attributes supported from Datatables:
 *
 *   * `class`, `displayLength`, `paginationType`
 *   * `serverSide`
 *
 * @example
 * Basic table with two columns using default capitalized title for 'name' column and defining title 'ID'  explicitly:
 * ```html
 * <neo-table src="api/customers/region">
 *   <neo-col name="id" title="ID">
 *   <neo-col name="name">
 * </neo-table>
 * ```
 *
 * @example
 * Default CSS classes can be overridden with 'class' attribute for whole tables and individual columns. Additional
 * attributes in the tables/column definitions are passed as DataTables options to the options/columns.
 * ```html
 * <neo-table src="api/customers/region" class="hover" displayLength="10">
 *   <neo-col name="id" class="red">
 *   <neo-col name="name" width="80%">
 * </neo-table>
 * ```
 */
function neoTable($compile) {

    // Mapping of lower-case attributes to the functions setting them in DataTables.
    // NOTE: Update documentation of neoTable when updating this list.
    var table_fn_options = {
            displaylength: 'withDisplayLength',
            paginationtype: 'withPaginationType',
    };

    // Mapping of lower-case attributes to names used in withOption() function.
    // NOTE: Update documentation of neoTable when updating this list.
    var table_options = {
    };

    /**
     * Helper to build options for DataTables based on `neoTable`-directive attributes.
     */
    function dtOptionsFromAttrs(options, scope, attrs) {

        var member, hasSrc = false;
        for(var a in attrs) {
            if(a.match(/^[a-z]/)) {
                if(a == 'src') {
                    hasSrc = true;
                    if(setup.hasServer() && scope.$eval(attrs.serverside)) {
                        options.withOption('serverSide', true);

                        // Set up the server communication for server-side processing.
                        options.withOption('ajax', function (data, callback, settings) {

                            // Make sure that valid URL is created.
                            var url = attrs.src;
                            if (url.indexOf("?") > -1) {
                                url += '&'; // URL already contains parameters
                            }
                            else {
                                url += '?'; // No existing URL parameters available
                            }
                            url += $.param(data);

                            storage.get(url, null, function(data) {
                                callback(data);
                            });
                        });

                        // Name of data field (from server) that contains the data to be displayed.
                        options.withDataProp('data');
                    }
                    else
                        options.sAjaxSource = attrs.src;
                }
                else if(a == 'class')
                    scope.classes = $attrs.class;
                else if(a == 'serverside')
                    ;
                else if(a in table_fn_options)
                    options[table_fn_options[a]](attrs[a]);
                else if(a in table_options)
                    options.withOption(table_options[a], scope.$eval(attrs[a]));
                else
                    d("Unsupported option '" + a + "' for neoTable.");
            }
        }

        if(!hasSrc)
            d("Cannot use neoTable without src-attribute.");

        return options;
    }

     /**
     * Create initial options and columns.
     */
    var controller = function($scope) {

        this.scope = $scope;

        $scope.open_row_template = '';
        $scope.can_open_rows = false;
        tables_in_use += 1;
        $scope.table_id = "NeoDataTable_" + tables_in_use;

        // Construct dtOptions with some forced defaults.
        if($scope.$parent.dtOptions)
            $scope.dtOptions = $scope.$parent.dtOptions;
        else
            $scope.dtOptions = DTOptionsBuilder.newOptions();

        $scope.dtOptions.withBootstrap();

        // Set up the server communication for client-side processing.
        if(!setup.hasServer() ||
                ($scope.dtOptions.serverSide !== true && $scope.dtOptions.serverSide !== undefined)) {
            $scope.dtOptions.withFnServerData(function (sSource, aoData, fnCallback, oSettings) {
                storage.get(sSource, null, function(data) {
                    fnCallback(data);
                });
            });
        }

        // Attach the clicking ability.
        $scope.dtOptions.withOption('rowCallback', function(row, data, displayIndex, displayIndexFull) {
            // Unbind first in order to avoid any duplicate handler (see https://github.com/l-lin/angular-datatables/issues/87)
            $('td', row).unbind('click');
            $('td', row).bind('click', function() {
                if($scope.can_open_rows) {

                    var table = $('#' + $scope.table_id).dataTable();

                    // Find the row element that has been clicked.
                    var row_element = $(this).parents('tr')[0];
                    if(table.fnIsOpen(row_element))
                        // TODO: Do we need to destroy scope here manually or is it automatic?
                        table.fnClose(row_element);
                    else {
                        var $new_scope = $scope.$new(true);
                        // TODO: What about old scope and content if it has been created? Is it reusable here?
                        $new_scope.$apply(function() {
                            table.fnOpen(row_element, $scope.open_row_template);
                            var opened_row = row_element.nextElementSibling;
                            $compile(opened_row)(angular.extend($new_scope, data));
                        });
                    }
                }
            });
        });

        // Setup column structure and dtColumns.
        if($scope.$parent.dtColumns)
            $scope.dtColumns = $scope.$parent.dtColumns;
        else
            $scope.dtColumns = [];

        this.addColumn = function(column) {
            if(column)
                $scope.dtColumns.push(column);
        };

        // Set up default classes.
        $scope.classes = default_classes;

        // Listen table reload requests
        $scope.$on('table-reload', function(/*event, message*/){
            $('#' + $scope.table_id).DataTable().ajax.reload();
        });
    };

    /**
     * Fill in additional options form directive attributes.
     */
    var linker = function($scope, $element, $attrs) {

        dtOptionsFromAttrs($scope.dtOptions, $scope, $attrs);
    };

    return {
        restrict: 'E',
        transclude: true,
        scope: {},
        controller: controller,
        link: linker,
        template: '<table id="{{table_id}}" ng-transclude datatable="" dt-options="dtOptions" dt-columns="dtColumns" class="{{classes}}"></table>'
    };
}
angular.module('widgets.data.forms').directive('neoTable', ['$compile', neoTable]);

/**
 * @ngdoc directive
 * @name neoCol
 * @module widgets.data.table
 *
 * @description
 * A description of the table column for `neoTable`.
 *
 * Attributes:
 *
 *   * `name` - Name of the column and source data field (required).
 *   * `title` - Column label (defaults to name with capital first letter).
 *   * `link` - Wraps a column data as link to the URL, where you can use fields of the data, e.g. '/view/object/{id}'
 *   * `width` - As in DataTables.
 */
function neoCol() {

    // Mapping of lower-case attributes to the names needed by DTColumns.
    // NOTE: Update documentation above when updating this list.
    var column_options = {
            width : 'sWidth'
    };

    /**
     * Helper to build columns for DataTables based on `neoCol`-directive
     * attributes.
     */
    function dtColumnFromAttrs(attrs) {

        // Check the name and the title.
        if (!attrs.name) {
            d("Name attribute is required for neoCol-directive.");
            return;
        }

        var column = DTColumnBuilder.newColumn(attrs.name);
        if (attrs.title)
            column.withTitle(attrs.title);
        else
            column.withTitle(ucfirst(attrs.name));

        // Handle rest of the attributes.
        for ( var a in attrs) {

            if (a.match(/^[a-z]/)) {
                if (a == 'name' || a == 'title')
                    continue;
                if (a == 'class')
                    column.withClass(attrs[a]);
                else if (a == 'link')
                    column.renderWith(linkRenderer(attrs[a]));
                else if (a in column_options)
                    column.withOption(column_options[a], attrs[a]);
                else
                    d("Unsupported option '" + a + "' for neoCol.");
            }
        }

        return column;
    }

     /**
     * Create column description and add it to the parent table.
     */
    var linker = function($scope, $element, $attrs, tableController) {

        tableController.addColumn(dtColumnFromAttrs($attrs));
    };

    return {
        restrict: 'E',
        require: '^neoTable',
        link: linker,
        template: ''
    };
}
angular.module('widgets.data.forms').directive('neoCol', neoCol);

/**
 * @ngdoc directive
 * @name neoOpenRow
 * @module widgets.data.table
 *
 * @description
 * An element containing hidden content for the `neoTable` row, which is displayed
 * when clicked.
 */
function neoOpenRow() {

    return {
        restrict: 'E',
        require: '^neoTable',
        transclude: true,
        template: '<div ng-transclude></div>',
        compile: function(element, attributes){
            return {
                post: function(scope, element, attributes, controller, transcludeFn){
                    controller.scope.can_open_rows = true;
                    controller.scope.open_row_template = element.children().html();
                    element.html('');
                }
            };
        }
    };
}
angular.module('widgets.data.forms').directive('neoOpenRow', neoOpenRow);
})(angular);
