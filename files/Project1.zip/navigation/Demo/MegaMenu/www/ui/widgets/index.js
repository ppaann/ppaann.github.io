/**
 * @ngdoc module
 * @name widgets
 * @module widgets
 *
 * @description
 * Top level module containing all widgets from all modules.
 */
(function(angular) {

angular.module('widgets', ['widgets.core',
                           'widgets.data',
                           ]);

})(angular);
