/**
 * @ngdoc module
 * @name widgets.data.forms
 * @module widgets.data.forms
 *
 * @description
 * Utilities for constructing forms based on data models.
 */
(function(angular) {

angular.module('widgets.data.forms', ['modules.core.network', 'modules.data.model']);

// Handle for models service.
var models;

/** Pre-fill some commonly used resources.
 */
function run(storage, _models) {
    storage.file('www/ui/widgets/data/input.html', function(){});
    storage.file('www/ui/widgets/data/input-string.html', function(){});
    models = _models;
}
angular.module('widgets.data.forms').run(['storage', 'models', run]);

/**
 * @ngdoc directive
 * @name neoForm
 * @module widgets.data.forms
 *
 * @description
 * Construct a form for a given `Values` model.
 *
 * Attributes:
 *
 *   * `title` - Title attribute of the form (name of the `Values` model if not given).
 *   * `model` - Name of the scope variable to be used as a model (default: 'model').
 *   * `model-class` - Name of the class to be instantiated as a model for this form.
 *   * `api` - An URL processing loading and saving data for the model defined in `model-class` attribute.
 *   * `submit` - Label for the submit button.
 *
 * Scope:
 *
 *   * `title` - Title attribute of the <neo-form> or name of the `Values` model if not given.
 *   * `form` - The form controller associated with this form.
 *   * `model` - Model instance associated with the form.
 *   * `submit_name` - Label for submit button.
 *   * `submit` - Function to be called on the pressing of submit.
 *   * `api` - Object with keys 'create', 'read', 'update' and 'delete' having URL for each API call.
 *
 * @example
 *
 * TODO: Review and write better examples.
 *
 * Let us assume that we have a model defined as
 *
 * ```javascript
 *    $scope.model = new Values({values: [{ref: 'name', type: 'string'},
 *                                        {ref: 'value', type: 'string'}]});
 * ```
 *
 * Then we can create a form for editing its value by:
 *
 * ```html
 * <neo-form title="Please Give Name and Value" model="model">
 *   <neo-input field="name"></neo-input>
 *   <neo-input field="value"></neo-input>
 *   <button ng-click="some_handler(my_model)>Handle</button>
 * </neo-form>
 * ```
 *
 * To simplify example further, one can let neoForm to handle details:
 * ```html
 * <neo-form title="Please Give Name and Value" submit="Handle"></neo-form>
 * ```
 * Here default scope variable `model` is used and then inputs and submits are filled with
 * defaults. To use this short form one needs to define handler function as `submit(model)` 
 * in the scope of the form.
 */
function neoForm($compile) {

    var controller = function($scope, $element, $attrs, $transclude) {

        this.scope = $scope;

        // TODO: Temporary test stuff to be dropped.
        $scope.Setup = new Setup();
        $scope.Configuration = new Configuration({"name": "Nimi", "version":"1.0", "settings": {
            "features": [{"name": "Feat1", "values": [{"ref": "val1", "type" : "string"},
                                                      {"ref": "val2", "type" : "string"},
                                                      {"ref": "val3", "type" : "string"}]
                         }]}});

        // Instantiate the model.
        if($attrs.modelClass){
            if($attrs.model)
                d("Attributes 'model' and 'model-class' are mutually exclusive for 'neoForm'.");
            $scope.model = new (models.class_of($attrs.modelClass))();
        }
        else
            $scope.model = $scope.$eval($attrs.model || 'model');

        if(!$scope.model) {
            $scope.title = "Model Missing";
            d("A directive 'neoForm' cannot operate without a model.");
            return;
        }

        // Set up some miscellaneous values.
        $scope.submit_name = $attrs.submit || ($attrs.api ? 'Save' : 'Submit');
        $scope.title = $attrs.title || $scope.model.name || "Unidentified Form";
    };

    // Linker fills in automatically input fields and submit button if none is given explicitly.
    var linker = function($scope, $element, $attrs) {

        if(!$scope.model)
            return;

        // Set up API call URLs.
        $scope.api = {};
        if($attrs.api) {
            $scope.api.create = $attrs.api;
            $scope.api.read = $attrs.api;
            $scope.api.update = $attrs.api;
            $scope.api.delete = $attrs.api;
        }

        // Fill in inputs if not given.
        var auto_element;
        if(!$element.find('neo-input').length) {

            var html = '';
            if('getTypes' in $scope.model) {
                // TODO: Extract this to separate helper function.
                // TODO: Support for description field.
                var types = $scope.model.getTypes();
                for(var t = 0; t < types.length; t++) {
                    var ref = types[t].ref;
                    if(!ref) {
                        d("Cannot build neoInput from description without 'ref': " + JSON.stringify(types[t]));
                        continue;
                    }
                    var type = types[t].type;
                    if(!type) {
                        d("Cannot build neoInput from description without 'type': " + JSON.stringify(types[t]));
                        continue;
                    }
                    var name = types[t].name || ref;
                    var label = types[t].label || camel2human(name);
                    var options = types[t].options || "";
                    if(options)
                        options = encodeURIComponent(JSON.stringify(options));


                    html += ('<neo-input ref="' + ref +
                            '" type="' + type +
                            '" name="' + name +
                            '" label="' + label +
                            '" options="' + options +
                            '"></neo-input>');
                }
            }

            // Compile and put in place if we have something.
            if(html) {
                auto_element = $element.find('.auto-fields');
                auto_element.html(html);
                $compile(auto_element.contents())($scope);
            }
        }

        // Fill in submit if not given.
        if(!$element.find('neo-submit').length) {
            auto_element = $element.find('.auto-submit');
            auto_element.html('<neo-submit title="' + $scope.submit_name + '"></neo-submit>');
            $compile(auto_element.contents())($scope);
        }

        // Call API for data if we have one.
        if($scope.api.read) {
            models.read($attrs.modelClass, $scope.api.read, function(model) {
                $scope.model = model;
                d("Loaded:", model);
            });
        }
    };

    return {
        restrict: 'E',
        scope: {},
        transclude: true,
        templateUrl: 'www/ui/widgets/data/form.html',
        controller: controller,
        link: linker
    };
}
angular.module('widgets.data.forms').directive('neoForm', ['$compile', neoForm]);

/**
 * @ngdoc directive
 * @name neoInput
 * @module widgets.data.forms
 *
 * @description
 * Construct an input element for a form. An input can handle fields of generic free form data structures or specifically
 * `Value` objects, which provides additional details without need to specify them on the directive.
 * TODO: Describe usage for other models.
 *
 * Options for all inputs:
 *
 *   * `viewonly` - If set, input is only for displaying the value and not for editing.
 *   * `required` - If set, the value must be set or it is considered an error.
 *
 * Options for 'string' inputs:
 *
 *   * `password` - If set, handle input as password field.
 *
 * Scope:
 *
 *   * `form` - The form controller associated with the form containing this input.
 *   * `model` - The model object of the parent form.
 *   * `name` - Name of the input variable for POST or PUT.
 *   * `value` - A separate `Value` object (if used).
 *   * `options` - An object containing all generic and type specific options.
 *
 * Attributes:
 *
 *   * `ref` - The name of the member we look from the model as a member or using `findRef()` function, if it exists.
 *   * `name` - Name of the input variable for POST or PUT (defaults to `ref`).
 *   * `type` - The type of the input (required for non-Value objects).
 *   * `label` - Label for the input (required for non-Value objects).
 *   * `options` - Additional options for the input behavior as an object.
 *                 These options can be also given as attributes.
 *
 * TODO: Examples
 */
function neoInput($compile, storage) {

    var linker = function($scope, $element, $attrs, neoFormController) {

        // Set up the model and form and check required attributes.
        $scope.form = neoFormController.scope.form;
        $scope.model = neoFormController.scope.model;
        if(!$scope.model)
            return;

        var ref = $attrs.ref;
        if(!ref) {
            d("Directive 'neoInput' requires ref-attribute.");
            return;
        }

        // Resolve the target value.
        var is_value_object = false;
        var ng_model;

        if('findRef' in $scope.model) {
            $scope.value = $scope.model.findRef(ref);
            if(!$scope.value) {
                d("Cannot find the ref '" + ref + "' in neoInput.");
                ng_model = 'value';
                is_value_object = false;
            } else {
                ng_model = 'value.value';
                is_value_object = true;
                $scope.display_value = $scope.value.value;
            }
        }
        else {
            ng_model = 'model.' + ref;
            $scope.display_value = $scope.$eval(ng_model);
        }

        // Resolve name.
        $scope.name = ref;
        if($attrs.name)
            $scope.name = $attrs.name;

        // Resolve type.
        if(is_value_object)
            $scope.type = $scope.value.type;
        else {
            $scope.type = "string";
            if(!$attrs.type)
                d("Input without associated `Value` object needs explicit type-attribute in 'neoInput'.");
            else
                $scope.type = $attrs.type;
        }

        // Resolve label.
        if(is_value_object)
            $scope.label = $scope.value.name;
        if($attrs.label)
            $scope.label = $attrs.label;
        if(!$scope.label)
            $scope.label = ucfirst(ref);

        // Collect the options and put them to the scope overriding from directives where given.
        $scope.options = {};
        if(is_value_object)
            $scope.options = angular.copy($scope.value.options);
        if($attrs.options)
            $scope.options = angular.extend($scope.$eval(decodeURIComponent($attrs.options)));
        for(var a in $attrs) {
            if(a[0] != '$' && a != 'ref' && a != 'name' && a != 'type' && a != 'options' && a != 'label')
                $scope.options[a] = $scope.$eval($attrs[a]);
        }

        // Construct and compile the HTML from the generic input/view template and type-specific input template.
        var file = $scope.options.viewonly ? 'view' : 'input';
        storage.file('www/ui/widgets/data/' + file + '-' + $scope.type + '.html', function(type_html) {
            storage.file('www/ui/widgets/data/input.html', function(html) {
                html = html.replace('[[input_html]]', type_html.replace(/\[\[ng_model\]\]/g, ng_model));
                $element.html(html);
                $compile($element.contents())($scope);
            });
        });
    };

    return {
        restrict: 'E',
        scope: {},
        require: '^neoForm',
        link: linker,
        template: ''
    };
}
angular.module('widgets.data.forms').directive('neoInput', ['$compile', 'storage', neoInput]);

/**
 * @ngdoc directive
 * @name neoSubmit
 * @module widgets.data.forms
 *
 * @description
 * Construct a submit button element for a form.
 *
 * Scope:
 *
 *   * `title` - Label on the submit-button (defaults to submit-attribute of neoForm).
 *   * `submit(model)` - Handler for submitting the form.
 *
 * @example
 *
 * ```html
 * <neo-submit title="Send"></neo-submit>
 * ```
 */
function neoSubmit() {

    // TODO: Automatically use enter for submitting.
    var linker = function($scope, $element, $attrs, neoFormController) {

        $scope.title = $attrs.title || neoFormController.scope.submit_name || 'Submit';
        $scope.submit = function() {
            // TODO: Note that here we can handle also even further automatically cases where URL is given as an attribute.
            if(!$scope.$parent.submit)
                d("Directive neoSubmit needs a parent scope with submit() function in the scope.");
            else
                $scope.$parent.submit(model);
        };
    };

    return {
        restrict: 'E',
        require: '^neoForm',
        scope: {},
        link: linker,
        templateUrl: 'www/ui/widgets/data/submit.html'
    };
}
angular.module('widgets.data.forms').directive('neoSubmit', neoSubmit);

})(angular);
