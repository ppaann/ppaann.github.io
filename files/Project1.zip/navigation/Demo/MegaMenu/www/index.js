/**
 * A list of files to load in the development version in their dependency order.
 */
window.neo_library_files =
[
    //'www/lib/jquery/jquery-1.11.1.js',
    'www/lib/angular/angular.js',
    'www/lib/angular/angular-ui-router.js',
    'www/lib/jquery/jquery.datatables.js',
    'www/lib/angular/angular-datatables.js',
    'www/lib/jquery/datatables.colvis.js',
    'www/lib/bootstrap/ui-bootstrap.js',
    //DEMO: metro
    //'www/lib/bootstrap/bootstrap.js',
    'www/lib/bootstrap/metro.min.js',

    // DEMO --end
    'www/lib/jquery/jquery.datatables.js',
    'www/lib/angular/select.js',
    'www/lib/angular/angular-sanitize.js'
];
window.neo_model_files =
[
    'www/models/utils.js',
    'www/models/base.js',
    'www/models/user/user.js',
    'www/models/core/setup.js',
    'www/models/core/page.js',
    'www/models/core/pages.js',
    'www/models/core/message.js',
    'www/models/core/messages.js',
    'www/models/data/value.js',
    'www/models/data/values.js',
    'www/models/configurations/setting.js',
    'www/models/configurations/feature.js',
    'www/models/configurations/settings.js',
    'www/models/configurations/configuration.js',
    'www/models/customers/admin.js',
];
window.neo_module_files =
[
    'www/ui/modules/core/neo.js',
    'www/ui/modules/core/network.js',
    'www/ui/modules/core/layout.js',
    'www/ui/modules/core/messaging.js',
    'www/ui/modules/user/login.js',
    'www/ui/modules/data/model.js',
    'www/ui/widgets/index.js',
    'www/ui/widgets/core/index.js',
    'www/ui/widgets/core/menu.js',
    'www/ui/widgets/data/forms.js',
    'www/ui/widgets/data/table.js',
    'www/ui/widgets/data/select.js',
    'www/ui/widgets/data/index.js',
    'www/ui/pages/index.js',
    'www/ui/pages/developer_tools/developer_tools.js',
    'www/ui/pages/user/user.js',
    'www/ui/pages/my_page/my_page.js',
    'www/ui/pages/variants/variants.js',
    'www/ui/pages/applications/applications.js',
    'www/ui/pages/product_admin/product_admin.js',
    'www/ui/pages/rest_api/rest_api.js',
    'www/ui/pages/sw_delivery/sw_delivery.js',
    'www/ui/pages/system_admin/system_admin.js',
    'www/ui/pages/customers/customers.js',
];
window.neo_test_files =
[
     'www/tests/unit/core/setup.js',
     'www/tests/unit/configurations/basics.js',
];

window.neo_application_files = window.neo_library_files.concat(window.neo_model_files).concat(window.neo_module_files);

/**
 * A description of all pages the application has.
 */
window.neo_page_map =
{
        "items":[
        {
            "name":"Home",
            "url":"/",
            "templateUrl":"www/ui/pages/my_page/index.html",
            "roles":["User"],
            "group":"main",
            "icon": "glyphicon-home",
            "color": "lime"
        },
        {
            "name":"Variants",
            "state": "Variant overview",
            "parent":"Home",
            "roles":["User"],
            "group":"main",
            "icon": "glyphicon-th-list",
            "color": "cyan"
        },
        {
            "name":"Variant overview",
            "parent":"Variants",
            "url":"/variants/",
            "templateUrl":"www/ui/pages/variants/list.html",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Edit Variant",
            "parent":"Variants",
            "url":"/variants/{variantId:[0-9]+}",
            "templateUrl":"www/ui/pages/variants/edit.html",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Configurations",
            "parent":"Home",
            "state":"Variant configuration list", // DEMO: direct to variant configuration
            "roles":["User"],
            "group":"main",
            "icon": "glyphicon-th",
            "color": "cyan"
        },
        /* // DEMO remove the overview page
        {
            "name":"Configuration overview",
            "parent":"Configurations",
            "url":"/configurations/",
            "templateUrl":"www/ui/pages/configurations/index.html",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        */
        {
            "name":"Variant Configuration",
            "parent":"Configurations",
            "state":"Variant configuration list",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Variant configuration list",
            "parent":"Variant Configuration",
            "url":"/configurations/variantconfigurations",
            "templateUrl":"www/ui/pages/configurations/variantConfList.html",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Variant Configuration changeset",
            "parent":"Variant Configuration",
            "url":"/configurations/variantconfigurations",
            "templateUrl":"www/ui/pages/configurations/variantConfList.html", //DEMO: navigation
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Variant Configuration release",
            "parent":"Variant Configuration",
            "url":"/configurations/variantconfigurations",
            "templateUrl":"www/ui/pages/configurations/variantConfList.html",//DEMO: navigation
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Customer Configuration",
            "parent":"Configurations",
            "state": "Customer configuration list",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Customer configuration list",
            "parent":"Customer Configuration",
            "url":"/configurations/customerconfigurations",
            "templateUrl":"www/ui/pages/configurations/customerConfList.html",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Customer configuration changeset",
            "parent":"Customer Configuration",
            "url":"/configurations/customerconfigurations/changeset",
            "templateUrl":"www/ui/pages/configurations/customerConfChangeset.html",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Customer configuration release",
            "parent":"Customer Configuration",
            "url":"/configurations/customerconfigurations/release",
            "templateUrl":"www/ui/pages/configurations/customerConfRelease.html",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Customer and Country Defaults",
            "parent":"Configurations",
            "state": "Customer configuration list", // DEMO
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"SIM Lock Configurations",
            "parent":"Configurations",
            "state": "Customer configuration list", // DEMO
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"ADC Configurations",
            "parent":"Configurations",
            "state": "Customer configuration list", // DEMO
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Customer configuration edit",
            "parent":"Customer Configuration list", // DEMO: in real case , should the editor be a separated component/widget?
            "url":"/configurations/customerconfigurations/{ConfigurationId:[0-9]+}",
            "templateUrl":"www/ui/pages/configurations/customerConfItemEdit.html",
            "roles":["User"],
            "icon": "",
            "color": "cyan"
        },
        {
            "name":"Customers",
            "parent":"Home",
            "url":"/customers",
            "templateUrl":"www/ui/pages/customers/list.html",
            "roles":["User"],
            "group":"main",
            "icon": "glyphicon-th",
            "color": "lime"
        },
        {
            "name": "Applications and Content",
            "parent":"Home",
            "url": "/applications",
            "templateUrl": "www/ui/pages/applications/index.html",
            "roles": ["User"],
            "group": "main",
            "icon": "glyphicon-file",
            "color": "lime"
        },
        {
            "name": "SW Delivery",
            "parent":"Home",
            "url": "/sw_delivery",
            "templateUrl": "www/ui/pages/sw_delivery/index.html",
            "roles": ["User"],
            "group": "main",
            "icon": "glyphicon-download",
            "color": "darkBrown"
        },
        {
            "name": "Product Admin",
            "parent":"Home",
            "url": "/product_admin",
            "templateUrl": "www/ui/pages/product_admin/index.html",
            "roles": ["User"],
            "group": "main",
            "icon": "glyphicon-briefcase",
            "color": "red"
        },
        {
            "name": "System Admin",
            "parent":"Home",
            "url": "/system_admin",
            "templateUrl": "www/ui/pages/system_admin/index.html",
            "roles": ["User"],
            "group": "main",
            "icon": "glyphicon-fire",
            "color": "red"
        },
        {
            "name": "Developer Tools",
            "parent":"Home",
            "url": "/developer_tools",
            "templateUrl": "www/ui/pages/developer_tools/index.html",
            "roles": ["Developer"],
            "group": "main",
            "icon": "glyphicon-wrench",
            "color": ""
        },
        {
            "name": "Jasmine Tests",
            "parent": "Developer Tools",
            "url": "/developer_tools/tests",
            "templateUrl": "www/ui/pages/developer_tools/tests.html",
            "roles": ["Developer"],
            "group": "sub",
            "icon": "glyphicon-wrench",
            "color": ""
        },
        {
            "name": "UI Components",
            "parent": "Developer Tools",
            "url": "/developer_tools/ui",
            "templateUrl": "www/ui/pages/developer_tools/ui_components.html",
            "roles": ["Developer"],
            "group": "sub",
            "icon": "glyphicon-wrench",
            "color": ""
        },
        {
            "name": "REST API",
            "parent": "Developer Tools",
            "url": "/developer_tools/rest_api",
            "templateUrl": "www/ui/pages/rest_api/index.html",
            "roles": ["Developer"],
            "group": "sub",
            "icon": "glyphicon-wrench",
            "color": ""
        },
        {
            "name":"Login",
            "url":"/login",
            "templateUrl":"www/ui/pages/user/login.html",
            "roles":["Anonymous"],
            "group":"login",
            "icon": "glyphicon-user",
            "color": "",
            "has_menu":  false
        }
        ]
};

/**
 * A function performing the launching of the application.
 */
window.neo_boot = function(setup) {
    angular.module('Neo', ['modules.core.neo']);
    angular.module('modules.core.neo').value('setup', setup);
    angular.module('modules.core.neo').value('pages', new Pages(window.neo_page_map));
    angular.element(document).ready(function() {angular.bootstrap(document, ['Neo']);});
};

/**
 * Load all javascript files in the defined order and then execute the `launcher` function.
 */
window.neo_load = function(launcher) {

    function symbol(file) {return file.replace(/[^a-z]/g, '_');}

    var files = window.neo_application_files;

    $script(files[0], symbol(files[0]));
    var i;
    /* jshint -W083 */
    for(i=0; i < files.length - 1; i++) {
        (function(symbol, file, next_symbol) {$script.ready(symbol, function() {
            $script(file, next_symbol);
        });})(symbol(files[i]), files[i+1], symbol(files[i + 1]));
    }
    /* jshint +W083 */

    $script.ready(symbol(files[i]), launcher);
};
