/**
 * Debug utility to dump every argument to the console and returning the last argument.
 */
d = function() {
    var ret;
    for(var i in arguments) {
        ret = arguments[i];
        console.log(ret);
    }
    return ret;
};

/**
 * Convert first letter of the string to uppercase.
 */
ucfirst = function(str) {
    return str[0].toUpperCase() + str.substr(1);
};

/**
 * Convert camelCase or lower_case variable to human readable space-separated words.
 */
camel2human = function(str) {
    return ucfirst(str.replace(/_/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2'));
};
