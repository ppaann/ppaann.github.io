/**
 * Region data.
 */
Region = Values;


/**
 * Corporation data.
 */
Corporation = Values;


/**
 * MOID data.
 */
MOID = Values;


/**
 * Country data.
 */
Country = Values;


/**
 * MCC data.
 */
MCC = Values;


/**
 * MNC data.
 */
MNC = Values;


/**
 * Country group data.
 */
CountryGroup = Values;


/**
 * SIM lock data.
 */
SIMLock = Values;


/**
 * Operator data.
 */
Operator = Values;


/**
 * Trade customer data.
 */
TradeCustomer = Values;


/**
 * Customer data.
 */
Customer = Values;
