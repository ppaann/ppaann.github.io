/**
 * A generic model for an editable value.
 *
 * Currently supported types and options are documented in ui/widgets/data/forms.js.
 */
function Value(data) {

    // Code reference name of the value without space or special characters.
    this.ref = null;
    // Long name of the value.
    this.name = null;
    // Even longer description of the value.
    this.description = null;
    // Type of the value as a string.
    this.type = null;
    // Value presentation as internal Javascript object or primitive value.
    this.value = undefined;
    // Additional type specific options.
    this.options = {};
    // An expression determining if this value is relevant currently (for future ConfML support).
    this.relevant = null;
    /// A `Values` collection this value belongs to if any.
    this.parent = null;

    /**
     * Construct either `ref` or `name` from each other if missing.
     */
    this.postLoad = function() {
        // Add default `ref` based on `name` if not given.
        if(this.ref === null && this.name !== null)
            this.ref = this.name.replace(/ /g, '_').replace(/[^0-9a-zA-Z_]/g, '').toLowerCase();

        // Add default `name` based on `ref` if not given.
        if(this.name === null && this.ref !== null) {
            this.name = camel2human(this.ref);
        }
    }

    /**
     * Collect values for posting.
     *
     * Construct an object with each values `ref` field as a key and their `value` as a value.
     */
    this.forPOST = function() {
        return this.value;
    };

    this.load(data);
}
Value.prototype = new NeoModel();
