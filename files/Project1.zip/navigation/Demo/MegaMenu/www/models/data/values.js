/**
 * A generic model for group of editable values.
 *
 * Currently supported grouping types are:
 *
 *   * `labeled-form` - Simple labeled list of values editable together in a single form.
 */
function Values(data) {

    // Code reference name of the group without spaces and special characters.
    this.ref = null;
    // Long name of the group.
    this.name = null;
    // Even longer description of the group.
    this.description = null;
    // Type of the group as a string.
    this.type = 'labeled-form';
    // A list of `Value` objects.
    this.values = [];
    // Additional group type specific options.
    this.options = {};

    /**
     * Construct a type description from values.
     */
    this.getTypes = function() {
        var ret = [];
        for(var i=0; i < this.values.length; i++) {
            ret.push({
                ref: this.values[i].ref,
                name: this.values[i].name,
                description: this.values[i].description,
                type: this.values[i].type,
                options: this.values[i].options
            });
        }
        return ret;
    };

    /**
     * Connect values to this as parent.
     */
    this.postLoad = function() {
        for(var i=0; i < this.values.length; i++) {
            this.values[i].parent = this;
        }
    };

    /**
     * Collect values for posting.
     *
     * Construct an object with each values `ref` field as a key and their `value` as a value.
     */
    this.forPOST = function() {
        var ret = {};

        for(var i=0; i < this.values.length; i++) {
            ret[this.values[i].ref] = this.values[i].forPOST();
        }

        return ret;
    };

    /**
     * Scan for values and look for given `Value` with the specific `ref`.
     * @param {string} name Value of the ref field we are looking for.
     * @return {Value} A value object having the ref or null if not found.
     */
    this.findRef = this.makeFindFunction('values', 'ref');

    this.load(data, {values: [Value]});
}
Values.prototype = new NeoModel();
