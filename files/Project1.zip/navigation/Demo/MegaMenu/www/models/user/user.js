/**
 * User information.
 */
function User(data) {

    // User's unique account name.
    this.username = null;
    // First name of the user.
    this.first_name = null;
    // Last name of the user.
    this.last_name = null;
    // Email address of the user.
    this.email = null;
    // Roles that the user has.
    this.roles = ['Anonymous'];

    this.load(data);

    /**
     * Check if the user is logged in.
     */
    this.isLoggedIn = function() {
        return !this.hasRole('Anonymous');
    };

    /**
     * Get display name for the user.
     */
    this.name = function() {
        if(this.first_name && this.last_name)
            return this.first_name + ' ' + this.last_name;
        return this.first_name || this.last_name || this.username;
    };

    /**
     * Check if the user has the given role or any of the roles in the list.
     */
    this.hasRole = function(args) {
        if(typeof(args) == 'object') {
            for(var i=0; i < args.length; args++) {
                if(this.hasRole(args[i]))
                    return true;
            }
            return false;
        } else {
            return this.roles.indexOf(args) > -1;
        }
    };
}

User.prototype = new NeoModel();
