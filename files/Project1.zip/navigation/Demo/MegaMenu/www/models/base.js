/**
 * Base class for models used in Neo.
 */
function NeoModel() {

    /**
     * Load data into this object.
     *
     * @param {object} data JSON data to fill members of this object.
     * @param {object} model_map A mapping from field names to additional processing instructions.
     *
     * This object is checked that it has initialized the member before filling
     * in the value. If it is not, then an error is displayed on console. Optionally
     * one or more members can have additional processing instead of assigning direct value.
     * Format is
     *
     *     this.load(data, {item_field: Class1, list_field: [Class2]});
     *
     * If simple class function is given, it is instantiated as an object. If the class function is
     * wrapped into array, then the corresponding data is taken as a list of objects and automatically
     * instantiated as a list of objects.
     */
    this.load = function(data, model_map) {

        data = this.preLoad(data);

        var mapping;
        if (!model_map)
            model_map = {};

        // Create members from data.
        for(var k in data) {

            mapping = model_map[k];
            if (k in this) {
                if (mapping) {
                    if(0 in mapping)
                        this[k] = this.makeList(mapping[0], data[k] || []);
                    else
                        this[k] = new mapping(data[k]);
                } else
                    this[k] = data[k];
            } else {
                d("Invalid member '" + k + "' offered for model:", this);
                d("Offered member was:", data[k]);
            }
        }

        this.postLoad();
    };

    /**
     * Pre-processing hook for a data loader.
     *
     * @param {object} data Original JSON data to fill members of this object.
     * @return {object} Processed JSON data.
     *
     * By default this function does nothing.
     *
     * NOTE: This function must be defined before calling load() function.
     */
    this.preLoad = function(data) {
        return data;
    };

    /**
     * Post-processing hook for a data loader.
     *
     * By default this function does nothing.
     *
     * NOTE: This function must be defined before calling load() function.
     */
    this.postLoad = function() {
    };

    /**
     * Construct an array of objects from list of data.
     *
     * @param {class} model A `NeoModel` class function.
     * @param {Array} list An array of JSON-objects to use for constructing models.
     *
     * @returns An array of `NeoModel` objects.
     */
    this.makeList = function(model, list) {
        var ret = [];
        if(list) {
            for(var i in list) {
                if(list[i] instanceof NeoModel)
                    ret.push(list[i]);
                else
                    ret.push(new model(list[i]));
            }
        }

        return ret;
    };

    /**
     * Collect values for posting.
     *
     * By default this is JSON presentation of the object.
     */
    this.forPOST = function() {
        return angular.fromJson(angular.toJson(this));
    };

    /**
     * Create a search function for member list lookup.
     * @param {string} my_member Name of the member field containing list of other objects.
     * @param {string} key Name of the target field in the listed objects.
     * @return {Function} A search function scanning the list for a matching object or null if not found.
     */
    this.makeFindFunction = function(my_member, key) {

        return function(value) {
            for(var i=0; i < this[my_member].length; i++) {
                if(this[my_member][i][key] == value)
                    return this[my_member][i];
            }
            return null;
        };
    };
}
