/**
 * Configuration data.
 */
function Configuration(data) {

    // ID number of the configuration.
    this.id = null;
    // Name of the configuration.
    this.name = null;
    // Version number of the configuration.
    this.version = null;
    // Configurable settings of this configuration.
    this.settings = null;

    this.load(data, {settings: Settings});

    this.getTypes = function() {
        return [{ref: 'name', type: 'string', options: {required: true}},
                {ref: 'version', type: 'string', options: {viewonly: true}}];
    }
}
Configuration.prototype = new NeoModel();
