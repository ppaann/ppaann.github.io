/**
 * A grouping element containing either configurable settings or other groups.
 */
function Feature(data) {

    this.load(data, {values: [Setting]});
}
Feature.prototype = new Values();
