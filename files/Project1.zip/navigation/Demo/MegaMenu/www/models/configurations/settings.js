/**
 * A collection of features and settings.
 */
function Settings(data) {

    // A list of features this setting contains.
    this.features = [];

    this.load(data, {features: [Feature]});

    /**
     * Scan for values and look for given `feature` with the specific `ref`.
     * @param {string} name Value of the ref field we are looking for.
     * @return {Value} A value object having the ref or null if not found.
     */
    this.findRef = this.makeFindFunction('features', 'ref');
}
Settings.prototype = new NeoModel();
