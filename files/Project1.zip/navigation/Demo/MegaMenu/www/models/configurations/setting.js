/**
 * A configurable value.
 */
function Setting(data) {

    this.load(data);
}
Setting.prototype = new Value();
