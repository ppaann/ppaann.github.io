/**
 * A description of a message.
 */
function Message(data) {

    // Type of the message ('danger', 'warning', 'info', 'success').
    this.type = '';
    // Message title.
    this.title = '';
    // Message.
    this.message = '';
    // If set, disable closing.
    this.permanent = false;
    // Bootstrap glyph icon name.
    this.icon = "";


    /**
     * Fill in icons based on type.
     */
    this.postLoad = function() {

        if(!this.icon){
            if (this.type == "info"){
                this.icon = "glyphicon glyphicon-info-sign";
            }
            else if (this.type == "warning"){
                this.icon = "glyphicon glyphicon-warning-sign";
            }
            else if (this.type == "success"){
                this.icon = "glyphicon glyphicon-check";
            }
            else if (this.type == "danger"){
                this.icon = "glyphicon glyphicon-exclamation-sign";
            }
        }
    };

    this.load(data);
}
Message.prototype = new NeoModel();
