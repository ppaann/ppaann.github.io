/**
 * A description of a page.
 */
function Page(data) {

    // Name of the page.
    this.name = null;
    // State of the page (defaults to name).
    this.state = null;
    // Name of the parent page if any.
    this.parent = null;
    // URL pattern of the corresponding page.
    this.url = null;
    // Path to the template file implementing the page.
    this.templateUrl = null;
    // A list of roles required in order to access the page.
    this.roles = [];
    // Name of the menu group the page belongs.
    this.group = null;
    // Icon to be shown in the My Page.
    this.icon = null;
    // Background color for icon.
    this.color = null;
    // If false, this page has no menu entry (marked automatically if URL has parameters).
    this.has_menu = true;

    // Container of this page if any.
    this.collection = null;
    // If set, this page is active or it is parent of an active page.
    this.active = false;


    /**
     * Collect a list of siblings for the page.
     *
     * Sibling is considered to be a pages with the same parent. For example,
     * if page defines parent as null (root pages), then all other pages
     * defining parent as null, would be considered as a sibling for the first
     * page.
     *
     * @return {Array} List of pages.
     */
    this.siblings = function() {

        if(!this.parent)
            return this.collection.findAll('parent', null);

        return this.collection.findAll('parent', this.parent);
    };

    /**
     * Collect a list if children for the page.
     *
     * @param {string} group If given, select only children of this group.
     * @return {Array} List of pages that have this page as a direct parent.
     */
    this.children = function(group) {
        var ret = [];
        for (var i = 0; i < this.collection.items.length; i++) {
            //DEMO: the group is no use here
            //if (this.collection.items[i].parent == this.name && (!group || this.collection.items[i].group == group))
            if (this.collection.items[i].parent == this.name)
                ret.push(this.collection.items[i]);
        }
        return ret;
    };

    /**
     * Get all page names starting from this page up until to the topmost parents.
     */
    this.nameChain = function() {

        var ret = [];
        ret.push(this.name);

        var page = this;
        while (page.parent !== null) {
            page = this.collection.find(page.parent);
            ret.push(page.name);
        }

        ret.reverse();

        return ret;
    };

    /**
     * Get the parent page object if any.
     * @return {Page} Parent of this page.
     */
    this.getParent = function() {
        return this.parent ? this.collection.find(this.parent) : null;
    };

    /**
     * Find the root page.
     */
    this.getRoot = function() {
        var ret = this;
        if(this.parent)
            return this.parent.getRoot();
        return this;
    };

    /**
     * Recursively mark this page and its parents as active after cleaning all active flags.
     */
    this.markActive = function() {
        this.cleanActiveState();
        this.markNameChainActive();
    };
    /*
    * reset all active state
    */
    this.cleanActiveState = function(){
        for (var i = 0; i < this.collection.items.length; i++) {
            this.collection.items[i].active = false;
        }
    }

    /*
    * Mark all pages in the name chain as active
    */
    this.markNameChainActive =function(){
        this.active = true;
        var parent = this.getParent();
        if(parent)
            parent.markNameChainActive();
    }

    /**
     * Mark pages with parameters that they do not have menus.
     */
    this.postLoad = function() {
        if(!this.state)
            this.state = this.name;
        if(this.url && this.url.match(/\{/))
            this.has_menu = false;
    };

    this.load(data);
}
Page.prototype = new NeoModel();
