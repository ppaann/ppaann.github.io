/**
 * A collection of message items.
 */
function Messages(data) {
    // A list of messages.
    this.items = {};

    this.load(data, {items: [Message]});
}


Messages.prototype = new NeoModel();
