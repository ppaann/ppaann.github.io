/**
 * A collection of Page items, i.e complete page map.
 */
function Pages(data) {
    // A list of page descriptions in the application.
    this.items = [];

    /**
     * Check that current page contains any of the provided roles.
     *
     * @param {Page} page: Page to be checked.
     * @param {Array of Strings} roles: List of roles to be checked.
     * @return {Boolean} true or false depending whether roles can be found or not.
     */
    function checkRoles(item, roles) {
        if(item.roles.length > 0) {
            for(var r in roles)
                if(item.roles.indexOf(roles[r]) >= 0) {
                    return true;
                }
        }

        return false;
    }

    /**
     * Find a page based on field and its value.
     *
     * This methods search through all the pages and returns the first
     * page that matches the given arguments. Field can be any key found
     * from Page model.
     *
     * @example:
     *     // This would return a page, whose name is
     *     find('name', 'Home');
     *
     * @param {String} field: Name of the field used to identify the page.
     * @param {String} value: The value that given field should contain.
     * @return {Page} Page found or null
     */
    this.find = function(field, value) {
        if (arguments.length == 1) {
            value = field;
            field = 'name';
        }
        for (var i in this.items) {
            if (this.items[i][field] == value) {
                return this.items[i];
            }
        }
    };

    /**
     * Collect all items in the list based on field and value.
     *
     * @param {String} field: Name of the field used to identify the page.
     * @param {String} value: The value that given field should contain.
     * @param {String} key: Name of the field, which value should be added to the
     *                      list.
     * @return {Array} Array of pages or Array of field values depending on
     *                 availability of 'key' parameter.
     */
    this.findAll = function(field, value, key) {
        var found = [];
        for (var i in this.items) {
            if (this.items[i][field] == value) {
                if (!key) {
                    found.push(this.items[i]);
                } else {
                    found.push(this.items[i][key]);
                }
            }
        }
        return found;
    };

    /**
     * Collect a list of all allowed pages user can access based on roles.
     *
     * @param {String} roles: List of roles of the user.
     * @return {Array} List of pages matching the parameters.
     */
    this.userPages = function(roles) {

        var pages = [];

        for (var i in this.items) {
            page = this.items[i];

            if (!checkRoles(page, roles) || !page.has_menu) {
                continue;
            }
            pages.push(page);
        }

        return new Pages({items: pages});
    };

    /**
     * Get the name of the default page.
     *
     * @param {Setup} Current setup.
     */
    this.defaultPage = function(setup) {
        if(setup.hasUser())
            return "Home";
        return "Login";
    };

    /**
     * Connect pages to this collection.
     */
    this.postLoad = function() {
        for(var i=0; i < this.items.length; i++) {
            this.items[i].collection = this;
        }
    };

    this.load(data, {items: [Page]});
}
Pages.prototype = new NeoModel();
