/**
 * Application settings and status information.
 */
function Setup(data) {

    // Version number of the application.
    this.version = '0.0';
    // Running mode of the application 'local-file', 'local-server', 'server-maintenance' or 'production-server'.
    this.mode = 'local-file';
    // Currently selected page layout 'default' or 'plain'.
    this.layout = 'default';
    // Current user or null if not logged in.
    this.user = null;
    // Current collection of UI messages.
    this.messages = null;

    this.load(data, {user: User, messages: Messages});

    /**
     * Check if we have a logged in user.
     */
    this.hasUser = function() {
        if(this.user)
            return this.user.isLoggedIn();
        return false;
    };

    /**
     * Mark the current user logged out.
     */
    this.logout = function() {
        this.user = new User();
        this.layout = 'plain';
    };

    /**
     * Log user in.
     */
    this.login = function(user) {
        this.user = user;
        this.layout = 'default';
    };

    /**
     * Check if we are running on server.
     */
    this.hasServer = function() {
        return this.mode.indexOf('server') >= 0;
    };
}
Setup.prototype = new NeoModel();
