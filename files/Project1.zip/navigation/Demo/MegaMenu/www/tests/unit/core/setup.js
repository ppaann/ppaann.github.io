describe("System setup", function() {

    var setup = new Setup();

    it("has no user by default", function() {
        expect(setup.hasUser()).toBeFalsy();
    });

    it("has user after login", function() {
        setup.login(new User({username: "test", roles: ['User']}));
        expect(setup.hasUser()).toBeTruthy();
    });

    it("has no user after logout", function() {
        setup.logout();
        expect(setup.hasUser()).toBeFalsy();
    });
});
