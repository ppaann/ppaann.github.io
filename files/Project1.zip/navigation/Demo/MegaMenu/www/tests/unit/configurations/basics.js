describe("Configuration", function() {

    var config = new Configuration({name: "Foo", settings: {features: [
                                                                       {ref: 'feat1', values: [
                                                                                               {ref: 'var1'},
                                                                                               {ref: 'boo', value: 91}
                                                                                               ]},
                                                                       {ref: 'feat2', values: [
                                                                                               {ref: 'var2'},
                                                                                               {ref: 'boo', value: 92}
                                                                                               ]}
                                                                                               ]}});

    it("has been constructed from JSON correctly", function() {
        expect(config.settings.findRef('feat1').findRef('var1').value).not.toBeDefined();
        expect(config.settings.findRef('feat1').findRef('boo').value).toBe(91);
        expect(config.settings.findRef('feat2').findRef('var2').value).not.toBeDefined();
        expect(config.settings.findRef('feat2').findRef('boo').value).toBe(92);
    });
});
