// conf.js
exports.config = {
  // If you want protractor to start the server for you, remove;
  //seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['*_spec.js'],
  baseUrl: 'http://localhost:9001'
};
