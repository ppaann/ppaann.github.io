// protractor end-to-end jasmine specs
// specs can be run with grunt, starting grunt server, selenium etc.
//
// $ grunt e2e_specs

describe('neo develop view', function() {
	it('should have a title', function() {
		browser.get('/develop.html');
		console.log("test 1 - base", browser.baseUrl);
		expect(browser.getTitle()).toEqual('Neo Configurator');
	});
});

/*
// TODO: this used to work with the old login screen...
describe('neo login', function() {
	var ptor;

	beforeEach(function() {
		// GIVEN user opens the login page
		browser.get(browser.baseUrl + '/develop.html#/login');
		ptor = protractor.getInstance();
	});

	it('should redirect to Home', function() {
		var ff = element(by.cssContainingText('h1', 'Login (pure angular)'));
		expect(ptor.isElementPresent(ff)).toBe(true);
		// WHEN user enters login credentials
		element(by.css('input[name:username]')).sendKeys('user_neo');
		element(by.css('input[name:password]')).sendKeys('passwd_morpheussucks');
		// AND clicks the
		element(by.buttonText("Login")).click();
		// THEN I should see Home with neo menu
		expect(ptor.isElementPresent(element(by.css('neo-menu')))).toBe(true);
	});
});
*/