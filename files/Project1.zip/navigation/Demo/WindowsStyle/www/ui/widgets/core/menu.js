/**
 * @ngdoc module
 * @name widgets.core.menu
 * @module widgets.core.menu
 *
 * @description
 * A module providing tools for displaying menus based on their accessibility.
 */
(function(angular) {

angular.module('widgets.core.menu', ['modules.core.neo']);

/**
 * @ngdoc directive
 * @name neoMenu
 * @module widgets.core.menu
 *
 * @description
 * Display menus of the given menu group.
 *
 * Scope:
 *
 *   * `setup` - System `Setup` object.
 *   * `currentPage` - A `Page` object of the current page.
 *   * `activeState` - A list of page names with the current page last and its parents before it.
 *   * `siblings` - A list of `Page` objects sharing the parent of the current page.
 *   * `subMenus` - A list of `Page` objects that belongs to the current submenu.
 *
 * @example
 * ```html
 * <neo-menu></neo-menu>
 * ```
 */
function MenuController($scope, $state, pages, setup) {

    $scope.setup = setup;

    // Helper to update scope.
    function _update_scope($scope, $state, pages, setup) {
        var userPages = pages.userPages(setup.user.roles);
        $scope.siblings = {};
        $scope.activeState = [];
        $scope.mainNavMenu = []; // main navigation menu items
        $scope.subNavMenu = []; // sub navigation menu items
        $scope.currentPage = userPages.find("name", $state.current.name);
        if(!$scope.currentPage)
            return;
        $scope.currentPage.markActive();
        $scope.activeState = $scope.currentPage.nameChain();
        $scope.sitePage = $scope.currentPage; // site is either the Home or the 1st level components
        for(var p = 0; p < $scope.activeState.length; p++) {
            var page_name = $scope.activeState[p];
            $scope.siblings[page_name] = userPages.find(page_name).siblings();
        }

        //DEMO: The code need to be finetuned  then remove this demo comment -->
        // set main navigation menu
        if($scope.activeState.length > 1){
            // the Site page should be current the 1st level component
            $scope.sitePage = userPages.find("name", $scope.activeState[1]);
            // In non-Home pages, the main menu should show the 2nd level menu items
            $scope.mainNavMenu = $scope.sitePage.children();
            // If there's 3rd level
            if($scope.activeState.length > 3){
                $scope.subNavMenu = userPages.find("name", $scope.activeState[2]).children();
            }
        }
        else {
            // At home page, the main menu shows home's children, which is the 1st level components
            $scope.mainNavMenu =$scope.currentPage.children();
        }
        // set submenu


        // eof DEMO <--



        /*
        if($scope.currentPage.group == 'sub')
            $scope.subMenus = $scope.currentPage.getParent().children('sub');
        else
            $scope.subMenus = $scope.currentPage.children('sub');
        */
    }

    _update_scope($scope, $state, pages, setup);

    $scope.$on('$stateChangeSuccess', function() {
        _update_scope($scope, $state, pages, setup);
    });
    $scope.$on('refresh', function() {
        _update_scope($scope, $state, pages, setup);
    });
}
function neoMenu() {
    return {
        templateUrl: 'www/ui/widgets/core/menu.html',
        controller: ['$scope', '$state', 'pages', 'setup', MenuController]
        };
}
angular.module('widgets.core.menu').directive('neoMenu', neoMenu);

})(angular);
